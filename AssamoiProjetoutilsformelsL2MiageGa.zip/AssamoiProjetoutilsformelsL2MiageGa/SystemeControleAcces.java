import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class SystemeControleAcces{
public static void main(String[] args) {
JFrame f=new JFrame();
f.setTitle("CONTROLE D'ACCES A LA PORTE");
f.setSize(500,600);
f.setMinimumSize(new Dimension(300,400));
f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
f.setVisible(true);
f.setLayout(new BorderLayout());
f.setBackground(Color.GRAY);


// creation de panneau
JPanel P=new JPanel();
P.setLayout(new GridLayout(4,1,5,5));


// titre principal

// creation cahmp de saisi

JTextField numeroField= new JTextField();
JTextField codeField=new JTextField();
// ajout des labels et zones de saisi
JLabel texte= new JLabel("N° DE LA CARTE",SwingConstants.CENTER);
texte.setFont(new Font("serif", Font.BOLD, 17));
P.add(texte);
P.add(numeroField);
JLabel texte1=new JLabel("PIN",SwingConstants.CENTER);
texte1.setFont(new Font("segeo print", Font.BOLD, 17));
P.add(texte1);
P.add(codeField);
f.add(P,BorderLayout.NORTH);







// Bouton valider
JButton buttonValider=new JButton("VALIDER");
buttonValider.setBackground(Color.GREEN);
buttonValider.setFont(new Font("serif", Font.BOLD, 20));
// clique boutonValider
JLabel sms=new JLabel();

    

f.add(sms,BorderLayout.CENTER);



buttonValider.addActionListener(new ActionListener() {

    @Override
    public void actionPerformed(ActionEvent e) {
        String text=numeroField.getText();
        String message=codeField.getText();

        if(!text.isEmpty()&& !message.isEmpty()){
            // Verification des numero et code pin saisi et Acces refuse/Accorde
            String mess="^\\d{8}[A-Za-za]{4}$";
            String condition="^\\d{4}$";
            if (text.matches(mess)&& message.matches(condition)) {
                sms.setText("Acces accordé");
                sms.setFont(new Font("serif",Font.ITALIC,30));
                sms.setHorizontalAlignment(SwingConstants.CENTER);
                sms.setForeground(Color.GREEN);
            }
            else{
                sms.setText("Acces refusé");
                sms.setForeground(Color.RED);
                sms.setFont(new Font("serif",Font.ITALIC,30));

                sms.setHorizontalAlignment(SwingConstants.CENTER);
            }

        
        
        }
        else if(text.isEmpty()){
            sms.setText("Entrez votre numero de carte !");
            sms.setHorizontalAlignment(SwingConstants.CENTER);
            sms.setForeground(Color.black);
            
            sms.setFont(new Font("serif", Font.ITALIC,  30));
            
        }
        else if(message.isEmpty()){
            sms.setText("Entrez votre code pin !");
            sms.setHorizontalAlignment(SwingConstants.CENTER);
            sms.setForeground(Color.black);
            
            sms.setFont(new Font("serif", Font.ITALIC,  30));
        }
  
    }
}


);

        
        
    



// bouton effacer
JButton buttoneffacer=new JButton("Effacer");
buttoneffacer.setFont(new Font("serif",Font.BOLD,20));
buttoneffacer.setBackground(Color.yellow);
buttoneffacer.addActionListener(new ActionListener() {

    @Override
    public void actionPerformed(ActionEvent e) {
        numeroField.setText("");
        codeField.setText("");
        
        
    }
    
});

JPanel panneauButtons=new JPanel();
panneauButtons.setLayout(new GridLayout(1,2,5,5));
panneauButtons.add(buttonValider);
panneauButtons.add(buttoneffacer);
f.add(panneauButtons,BorderLayout.SOUTH);


}



}


   


















